#define LENGTH 2
#include "ftoastr.c"
