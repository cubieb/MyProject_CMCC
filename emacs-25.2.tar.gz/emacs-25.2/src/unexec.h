#ifndef EMACS_UNEXEC_H
#define EMACS_UNEXEC_H
void unexec (const char *, const char *);
#endif /* EMACS_UNEXEC_H */
